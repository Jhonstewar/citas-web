---
name: Calm Clinical Clarity
colors:
  surface: '#f6f9ff'
  surface-dim: '#cedce9'
  surface-bright: '#f6f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#ebf5ff'
  surface-container: '#e2effe'
  surface-container-high: '#dceaf8'
  surface-container-highest: '#d6e4f2'
  on-surface: '#101d27'
  on-surface-variant: '#41474f'
  inverse-surface: '#25323c'
  inverse-on-surface: '#e6f2ff'
  outline: '#717880'
  outline-variant: '#c1c7d0'
  surface-tint: '#1a6393'
  primary: '#00446a'
  on-primary: '#ffffff'
  primary-container: '#0b5c8c'
  on-primary-container: '#a4d3ff'
  inverse-primary: '#94ccff'
  secondary: '#006b5f'
  on-secondary: '#ffffff'
  secondary-container: '#6df5e1'
  on-secondary-container: '#006f64'
  tertiary: '#0033a6'
  on-tertiary: '#ffffff'
  tertiary-container: '#1449d3'
  on-tertiary-container: '#c1ccff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cde5ff'
  primary-fixed-dim: '#94ccff'
  on-primary-fixed: '#001d32'
  on-primary-fixed-variant: '#004b74'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#dce1ff'
  tertiary-fixed-dim: '#b7c4ff'
  on-tertiary-fixed: '#001551'
  on-tertiary-fixed-variant: '#0039b5'
  background: '#f6f9ff'
  on-background: '#101d27'
  surface-variant: '#d6e4f2'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 25px
  body-md-medium:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 25px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm-medium:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 22px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system is built around the ethos of **calm, warm clinical clarity**. Serving patients, medical professionals, and administrators across the HIC (Hospital Internacional de Colombia) and ICV (Instituto del Corazón de Floridablanca) ecosystems in Santander, Colombia, the interface must balance clinical rigor with humane warmth. It is institutional yet welcoming, modern without being trendy, and accessible to multi-generational demographics facing stressful healthcare moments.

### Design Principles
- **Clarity Over Cleverness:** Information architecture prioritizes unambiguous status displays, immediate readouts of appointment details, and friction-free booking flows.
- **Warm Authority:** The visual tone avoids sterile, cold bureaucracy as well as synthetic consumer trends (no glassmorphism, aggressive neons, or multi-stop purple gradients). Depth is established through subtle, pristine surfaces and disciplined typography.
- **Localized Empathy:** UI copy uses warm, formal Colombian Spanish (using clear, courteous terminology such as "Solicitar cita", "Mis citas", "Sede HIC", "Sede ICV") to build trust across both self-service patients and operational clinical staff.
- **Accessible Legibility:** High contrast ratios, distinct dual-coded statuses (icon + color + label), and spacious click targets (minimum 44px) ensure comfort under emotional strain or physical impairment.

## Colors

The palette establishes an immediate atmosphere of clinical precision tempered with refreshing vitality. 

### Core Palette
- **Primary Deep Teal-Blue (`#0B5C8C`):** Represents institutional confidence, medical stability, and trust. Hover state resolves to `#094A71`, and active pressed states step down to `#06334F`.
- **Secondary Aqua (`#14B8A6`):** Provides an optimistic, modern accent for progress indicators, active step bars, selected booking chips, and current navigation states.
- **Neutral Core (`#14212B`):** Deep ink-charcoal for primary typography, avoiding the harshness of pure black while guaranteeing WCAG AAA compliance.
- **Secondary Neutral (`#5B6B7B`):** Slate-gray for captions, helper text, and secondary meta-information.
- **Surfaces & Canvases:**
  - Base Background: `#F4F7FA` (cool, restorative canvas)
  - Surface White: `#FFFFFF` (elevated cards, inputs, and flyouts)
  - Muted Surface: `#EEF3F7` (table headers, nested panels, input disabled fills)
  - Hairline Border: `#DCE4EB` (structural separators and element perimeters)

### Semantic Appointment Statuses
Statuses must never rely solely on color; each state is strictly paired with a designated icon and Spanish text string:
- **Solicitada (REQUESTED):** Text/Icon `#B45309`, Background `#FEF3C7`, Border `#FDE68A`
- **Aprobada (APPROVED):** Text/Icon `#15803D`, Background `#DCFCE7`, Border `#BBF7D0`
- **Rechazada (REJECTED):** Text/Icon `#B91C1C`, Background `#FEE2E2`, Border `#FECACA`
- **Cancelada (CANCELLED):** Text/Icon `#475569`, Background `#F1F5F9`, Border `#E2E8F0`
- **Atendida (COMPLETED):** Text/Icon `#1D4ED8`, Background `#DBEAFE`, Border `#BFDBFE`
- **No asistió (NO_SHOW):** Text/Icon `#374151`, Background `#E5E7EB`, Border `#D1D5DB`

## Typography

The typographic hierarchy pairs the human, geometric warmth of **Plus Jakarta Sans** for headings with the high-legibility, structural rhythm of **Inter** for dense tabular data, metadata, forms, and clinical notes.

### Usage Guidelines
- **Headings (Plus Jakarta Sans):** Applied to dashboard overviews, wizard milestone headers, modal titles, and section dividers. Tightened letter spacing (`-0.01em` to `-0.02em`) provides crisp executive authority.
- **Body & Controls (Inter):** Line heights are kept generous (approx. 1.55 multiplier) to promote scanning ease for older patients and doctors reviewing lengthy histories.
- **Data & Tables:** Tabular figures (`font-variant-numeric: tabular-nums`) must be enforced across dates, document numbers (Cédula de Ciudadanía), timestamps, and telephone inputs.

## Layout & Spacing

The application employs an 8px grid foundation with strict bounding structures to maintain spatial hygiene across desktop, tablet, and mobile breakpoints.

### Structural Framework
- **Shell Architecture:**
  - **Sidebar Navigation:** Fixed width of `240px` on desktop viewport (`>= 1024px`), containing hospital switcher (`HIC` / `ICV`), role badge, and semantic navigation items. On tablet and mobile, this collapses into an off-canvas drawer.
  - **Top Navigation Bar:** Height fixed at `64px`, spanning the content area with current view breadcrumb/title, hospital selector pill, notification center trigger with badge, and patient/doctor profile trigger.
  - **Main Viewport Canvas:** Centered content with a max container width of `1200px` to guarantee comfortable line lengths and structured form containment.
- **Responsive Breakpoints:**
  - **Mobile (< 768px):** Single-column stack, outer canvas margin `1rem`, bottom action bars for key workflows. Tables convert into stacked record cards.
  - **Tablet (768px - 1023px):** Collapsed icon sidebar or sheet menu, outer canvas margin `1.5rem`, multi-column layouts step down from 3 to 2 columns.
  - **Desktop (>= 1024px):** Full 240px sidebar, outer canvas padding `1.5rem` to `2rem`, standard 12-column fluid grid inside the 1200px max container with `1.5rem` gutters.

## Elevation & Depth

Visual separation relies primarily on surface differentiation and crisp 1px structural borders, reinforced with subtle, soft-diffusion ambient shadows. Heavy drop shadows and glassmorphic blurs are explicitly avoided to keep the environment grounded and clinically clear.

### Surface Tiers & Shadow Tokens
- **Tier 0 (Base Canvas):** Background color `#F4F7FA`. Unshadowed.
- **Tier 1 (Resting Cards, Table Containers, Inputs):** 
  - Background: `#FFFFFF`
  - Border: `1px solid #DCE4EB`
  - Shadow: `0 1px 2px rgba(16, 24, 40, 0.05)`
- **Tier 2 (Hovered Interactive Cards, Dropdowns, Date-pickers):**
  - Background: `#FFFFFF`
  - Border: `1px solid #DCE4EB`
  - Shadow: `0 4px 12px rgba(16, 24, 40, 0.07), 0 1px 3px rgba(16, 24, 40, 0.04)`
- **Tier 3 (Modals, Slide-Over Drawers, Toast Notifications):**
  - Background: `#FFFFFF`
  - Border: `1px solid #DCE4EB`
  - Shadow: `0 12px 32px rgba(16, 24, 40, 0.10), 0 2px 6px rgba(16, 24, 40, 0.04)`
  - Scrim: `rgba(20, 33, 43, 0.45)` backdrop with zero blur.

## Shapes

The geometric personality balances comfort with structural order:
- **Default Elements (`10px`):** Inputs, standard buttons, select dropdowns, search triggers, and appointment date/time selection tiles.
- **Structural Containers (`12px`):** Data cards, modal sheets, filter headers, and table wraps (`rounded-lg` level).
- **Nested Inner Surfaces (`8px`):** Nested summary panels, alert message insets, and inner thumbnail holders (`rounded-md` level).
- **Status Pills & Indicators (`9999px`):** Full-rounded capsule geometry reserved strictly for status pills, role tags, notification count dots, and circular avatar avatars.

## Components

### Buttons
- **Height & Touch Target:** Primary baseline height of `44px` with horizontal padding `space-md` (16px) and border radius of `10px`.
- **Primary:** Background `#0B5C8C`, text `#FFFFFF`, font weight 600. Hover: `#094A71`. Focus-visible: outline `2px solid #14B8A6` with 2px offset.
- **Secondary / Outlined:** Background `#FFFFFF`, border `1px solid #DCE4EB`, text `#0B5C8C`. Hover: background `#EEF3F7`, border `#CBD5E1`.
- **Ghost:** Background transparent, text `#5B6B7B`. Hover: background `#EEF3F7`, text `#14212B`.
- **Danger:** Background `#FEE2E2`, border `1px solid #FECACA`, text `#B91C1C`. Hover: background `#FDCACA`. For destructive confirmations, a solid `#B91C1C` button with white text is used.

### Inputs & Selects
- **Height & Geometry:** `44px` height, radius `10px`, background `#FFFFFF`, border `1px solid #DCE4EB`, font Inter 16px (prevents automatic iOS zooming).
- **Labels:** Positioned atop input, font size 14px, weight 500 (`#14212B`), with optional helper text below in 12px (`#5B6B7B`).
- **Focus State:** Border changes to `#0B5C8C` with a soft box-shadow ring: `0 0 0 3px rgba(11, 92, 140, 0.15)`.
- **Error State:** Border changes to `#B91C1C` with `0 0 0 3px rgba(185, 28, 28, 0.15)`. Helper error message presented in 12px `#B91C1C` with leading alert icon.

### Time & Date Selection Chips
- Interactive chips for scheduling slots: `40px` height, minimum width `88px`, border `1px solid #DCE4EB`, radius `10px`.
- **Selected State:** Background `#14B8A6`, border `#0D9488`, text `#FFFFFF`, font weight 600.
- **Unavailable State:** Background `#F4F7FA`, border `1px dashed #DCE4EB`, text `#94A3B8`, cursor `not-allowed`.

### Stepper (Reserva de Cita)
- Displayed horizontally at top of the booking flow:
  1. *Especialidad y Sede* (HIC / ICV)
  2. *Profesional y Fecha*
  3. *Datos del Paciente*
  4. *Confirmación*
- Completed steps display a `#14B8A6` circle with a check icon. The active step displays a `#0B5C8C` circle with white step index and bold label. Future steps use `#EEF3F7` with `#5B6B7B` text.

### Status Pills
- Compact capsules (`24px` height, padding `2px 10px`, radius `9999px`, font size 12px, font weight 600).
- Always include a 14px contextual icon on the left (e.g., check for *Aprobada*, clock for *Solicitada*, alert-triangle for *Rechazada*).

### Stat Cards (Doctor & Admin Dashboard)
- Container: `#FFFFFF` card, 12px radius, 1px `#DCE4EB` border, padding `20px`.
- Top: 36px icon container tinted in `#EEF3F7` housing a `#0B5C8C` icon, flanked by an inline trend badge.
- Middle: Large value in Plus Jakarta Sans 28px bold (`#14212B`).
- Bottom: Metric label in Inter 14px regular (`#5B6B7B`).

### Responsive Data Tables
- Header row: `#EEF3F7` background, uppercase 12px bold labels (`#5B6B7B`), height `40px`.
- Rows: `#FFFFFF` background, height `56px`, bottom border `1px solid #DCE4EB`.
- On mobile viewports, rows transform into standalone cards with explicit label-value rows to preserve complete readability without horizontal scroll degradation.

### Empty States & Modals
- **Empty States:** Clean, single-line SVG illustrations in primary teal-blue (`#0B5C8C`) tint, a 18px Plus Jakarta Sans title, a brief helper paragraph explaining why no records exist, and a primary action button ("Solicitar primera cita").
- **Modals:** Max width `520px` for dialogs, centered, with explicit header including a close icon button, structured body padding (`24px`), and a right-aligned footer button row with "Cancelar" (Ghost) and primary confirmation.